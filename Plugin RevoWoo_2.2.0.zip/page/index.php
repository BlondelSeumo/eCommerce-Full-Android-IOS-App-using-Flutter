<?php 

	function index_settings(){
		include(plugin_dir_path( __FILE__ ).'main_page.php');
	}

	function revo_mobile_banner(){
		include(plugin_dir_path( __FILE__ ).'main_banner_slider.php');
	}

	function revo_custom_categories(){
		include(plugin_dir_path( __FILE__ ).'main_custom_categories.php');
	}

	function revo_popular_categories(){
		include(plugin_dir_path( __FILE__ ).'main_popular_categories.php');
	}

	function revo_mini_banner(){
		include(plugin_dir_path( __FILE__ ).'main_mini_banner.php');
	}

	function revo_list_flash_sale(){
		include(plugin_dir_path( __FILE__ ).'main_flash_sale.php');
	}

	function revo_list_extend_products(){
		include(plugin_dir_path( __FILE__ ).'main_extend_products.php');
	}

	function revo_intro_page(){
		include(plugin_dir_path( __FILE__ ).'main_intro_page.php');
	}

	function revo_post_notification(){
		include(plugin_dir_path( __FILE__ ).'main_post_notification.php');
	}

	function revo_empty_result_image(){
		include(plugin_dir_path( __FILE__ ).'main_empty_result_image.php');
	}

?>