<div class="container-fluid mt-5">
  <header class="panel-heading mb-3 bg-white">
    <div class="panel-actions pt-2">
      <?php 
      global $revo_plugin_version;
      echo  'v'.$revo_plugin_version ?>
    </div>

    <h2 class="panel-title">
      <div class="d-flex align-items-center">
        <img src="<?php echo get_logo() ?>" class="img-fluid mr-3" style="width: 30px">
        REVO APPS - Flutter Woocommerce Full App Manager
      </div>
    </h2>
  </header>
</div>